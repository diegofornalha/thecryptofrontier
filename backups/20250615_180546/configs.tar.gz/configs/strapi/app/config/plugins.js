module.exports = {
  // Desabilitar telemetria
  'users-permissions': {
    config: {
      jwtSecret: process.env.JWT_SECRET,
    },
  },
};